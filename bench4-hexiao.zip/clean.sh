rm agent.jar
rm *.csv
rm *err

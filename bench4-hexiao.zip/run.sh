sh clean.sh
CP=".:$CLASSPATH"
javac -cp $CP pgm/*.java


cd spec

rv-monitor -d classes/mop -s *.rvm
javac -cp "$CP:.." classes/mop/*.java
rm classes/mop/*.java

cp -r ../pgm classes 
javamopagent *.aj classes
rm -r classes/pgm

mv agent.jar ..
cd ..

java -javaagent:agent.jar -d64 -Xms512m -Xmx4g -cp $CP pgm.SRSTest $1 $2 1> trace.csv 2> err

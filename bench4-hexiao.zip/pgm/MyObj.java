package pgm;

/**
 * Created by xiaohe on 3/21/15.
 */

public class MyObj {
    int id;
    public MyObj(int id) {
        this.id = id;
    }

    public void A() {

    }

    public void B() {

    }

    public void C() {

    }

	public void done() {}

}

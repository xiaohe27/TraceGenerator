package pgm;

/**
 * Created by xiaohe on 15-3-22.
 */
public class SRSTest {

        public static void run1(int testID, boolean runMore) {
            MyObj obj = new MyObj(testID);
            for (int i = 0; i < testID; i++) {
                obj.A();
                obj.B();
                obj.C();
            }

            if (!runMore)
            obj.done();
            else
            run(obj);

        }

        public static void run2(int testID) {
            MyObj obj = new MyObj(testID);
            for (int i = 0; i < testID; i++) {
                obj.A();
                obj.C();
                obj.C();
                obj.B();
                obj.A();
                obj.B();
            }
            obj.done();
        }


        public static void run3(int testID) {
            MyObj obj = new MyObj(testID);
            MyObj obj2 = new MyObj(testID + 1);
            for (int i = 0; i < testID; i++) {
                obj2.A();
                obj.C();
                obj2.C();
                obj.B();
                obj.A();
                obj2.B();
            }
            obj.done();
            obj2.done();
        }

        public static void run(MyObj obj) {
            obj.A();
            obj.B();
            obj.C();
            obj.done();
        }


    public static void main(String[] args) {
        System.out.print("event, MyObj\r\n");
        int iterNum = 17;
	if(args.length == 1) {
		iterNum = Integer.parseInt(args[0]);	
	}

	boolean validTrace = false;

	if(args.length == 2 && args[1].equals("good")) {
		validTrace = true;
	}
        

        for (int i = 0; i < iterNum; i++) {
            switch (i % 3) {
                case 0 :
                    run1(i, (i % 5 == 0 ? true : false));
                    break;

                case 1 :
                    run2(i);
                    break;

                case 2 :
                    run3(i++);
                    break;
            }
        }

	if (!validTrace) {
        MyObj bad = new MyObj(iterNum);
        bad.B();
        bad.A();
        bad.done();
	}
    }
}
